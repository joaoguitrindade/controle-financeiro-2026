# 📘 Tutorial Completo: Controle Financeiro 2026 com Supabase e GitHub Pages

Este guia ensina como colocar seu **Controle Financeiro 2026** no ar pelo **GitHub Pages**, com banco de dados e autenticação **100% em Nuvem no Supabase** (plano gratuito), sem nenhum vínculo com a Netlify e com sincronização instantânea entre celular e computador.

---

## 📋 Sumário
1. [Criar o Projeto no Supabase](#passo-1-criar-o-projeto-no-supabase)
2. [Criar a Tabela com Segurança RLS](#passo-2-criar-a-tabela-no-supabase-1-clique)
3. [Desativar Confirmação de E-mail](#passo-3-desativar-confirmação-de-e-mail)
4. [Obter as Credenciais da API](#passo-4-obter-as-credenciais-do-supabase)
5. [Publicar no GitHub Pages](#passo-5-publicar-no-github-pages)
6. [Primeiro Acesso e Login Multi-Dispositivo](#passo-6-primeiro-acesso-e-login)

---

### Passo 1: Criar o Projeto no Supabase
1. Acesse [supabase.com](https://supabase.com) e crie uma conta gratuita (você pode fazer login direto com sua conta do GitHub);
2. No painel inicial, clique em **"New project"**;
3. Preencha os campos:
   - **Name:** `Controle Financeiro 2026` (ou o nome que preferir);
   - **Database Password:** Crie e guarde uma senha forte;
   - **Region:** Escolha `South America (São Paulo)` para ter a menor latência possível;
   - **Pricing Plan:** Deixe selecionado o plano **Free** (Gratuito);
4. Clique em **"Create new project"** e aguarde cerca de 1 a 2 minutos enquanto o banco de dados é provisionado.

---

### Passo 2: Criar a Tabela no Supabase (1 clique)
1. No menu lateral esquerdo do Supabase, clique no ícone **SQL Editor** (ícone `>_`);
2. Clique no botão **"New query"**;
3. Copie e cole o código SQL abaixo:

```sql
-- 1. Cria a tabela de dados financeiros dos usuários
create table if not exists public.user_financial_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  encrypted_data jsonb not null,
  salt text not null,
  avatar_color text default '#2563eb',
  display_name text,
  updated_at timestamptz default now()
);

-- 2. Habilita o Row Level Security (RLS) para isolamento absoluto entre usuários
alter table public.user_financial_data enable row level security;

-- 3. Políticas de segurança: cada usuário só enxerga e edita seus próprios dados
drop policy if exists "Usuários podem ler seus próprios dados" on public.user_financial_data;
create policy "Usuários podem ler seus próprios dados"
  on public.user_financial_data for select using (auth.uid() = user_id);

drop policy if exists "Usuários podem inserir seus próprios dados" on public.user_financial_data;
create policy "Usuários podem inserir seus próprios dados"
  on public.user_financial_data for insert with check (auth.uid() = user_id);

drop policy if exists "Usuários podem atualizar seus próprios dados" on public.user_financial_data;
create policy "Usuários podem atualizar seus próprios dados"
  on public.user_financial_data for update using (auth.uid() = user_id);
```

4. Clique no botão verde **"Run"** (no canto inferior direito da tela). 
5. Aparecerá a mensagem `Success. No rows returned`. A tabela e as regras de segurança estão criadas!

---

### Passo 3: Desativar Confirmação de E-mail
Para que você possa criar sua conta e fazer login imediatamente em qualquer aparelho sem precisar abrir caixa de entrada:
1. No menu lateral esquerdo do Supabase, clique em **Authentication** (ícone de dois usuários/escudo);
2. No submenu, clique em **Providers** ➔ **Email**;
3. Desmarque a opção **"Confirm email"**;
4. Clique no botão **"Save"**.

---

### Passo 4: Obter as Credenciais do Supabase
1. No menu lateral esquerdo, clique no ícone de engrenagem no rodapé (**Project Settings**);
2. Clique na aba **API**;
3. Localize e copie dois valores:
   - **Project URL:** Exemplo: `https://abcdefghijkl.supabase.co`
   - **Project API keys ➔ anon (public):** Uma chave longa de texto começando com `eyJ...`

---

### Passo 5: Publicar no GitHub Pages
1. Acesse o [GitHub](https://github.com/new) e crie um novo repositório (ex.: `controle-financeiro-2026`);
2. Faça o upload do arquivo `index.html` (ou envie via Git);
3. No repositório, clique em **Settings** ➔ no menu lateral esquerdo, clique em **Pages**;
4. Em **Build and deployment ➔ Branch**, selecione a branch `main` (pasta `/root`) e clique em **Save**;
5. Aguarde cerca de 1 minuto e atualize a página. O GitHub exibirá o link do seu site:  
   `https://seu-usuario.github.io/controle-financeiro-2026/`.

---

### Passo 6: Primeiro Acesso e Login
1. Abra o link gerado pelo GitHub Pages no computador ou no celular;
2. Na tela de login, clique no botão **"⚙️ Configurar Conexão do Supabase"**;
3. Cole sua **Project URL** e sua **Anon Public Key** e clique em **Salvar e Conectar**;
4. Clique na aba **"Criar Nova Conta"**, escolha seu nome de usuário e uma senha (mínimo 6 caracteres);
5. Pronto! Você entrará no dashboard imediatamente.
6. **Teste no Celular:** Abra o mesmo link no celular, informe as credenciais de conexão do Supabase e digite seu usuário e senha. Todos os seus dados, gráficos e lançamentos aparecerão sincronizados instantaneamente!
