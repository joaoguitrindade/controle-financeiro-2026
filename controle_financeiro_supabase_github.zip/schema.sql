-- ============================================================
-- CONTROLE FINANCEIRO 2026 - SCHEMA SQL PARA O SUPABASE
-- Execute este script no SQL Editor do seu projeto Supabase
-- ============================================================

-- 1. Criação da tabela de dados financeiros dos usuários
create table if not exists public.user_financial_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  encrypted_data jsonb not null,
  salt text not null,
  avatar_color text default '#2563eb',
  display_name text,
  updated_at timestamptz default now()
);

-- 2. Habilitação do Row Level Security (RLS) para isolamento 100% à prova de vazamentos
alter table public.user_financial_data enable row level security;

-- 3. Políticas de segurança (Políticas RLS)
-- Garante que nenhum usuário consiga ver ou modificar dados de outra pessoa

drop policy if exists "Usuários podem ler seus próprios dados" on public.user_financial_data;
create policy "Usuários podem ler seus próprios dados"
  on public.user_financial_data
  for select
  using (auth.uid() = user_id);

drop policy if exists "Usuários podem inserir seus próprios dados" on public.user_financial_data;
create policy "Usuários podem inserir seus próprios dados"
  on public.user_financial_data
  for insert
  with check (auth.uid() = user_id);

drop policy if exists "Usuários podem atualizar seus próprios dados" on public.user_financial_data;
create policy "Usuários podem atualizar seus próprios dados"
  on public.user_financial_data
  for update
  using (auth.uid() = user_id);
